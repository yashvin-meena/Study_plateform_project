from django.db import models
from django.contrib.auth.models import User
# Create your models here.
class Card(models.Model):
    heading = models.CharField(max_length=40)
    img = models.CharField(max_length=70,default='img/homework.jpg')
    link = models.CharField(max_length=70,default='a')
    description = models.TextField()

class Notes(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    title = models.CharField(max_length=50)
    desc = models.TextField()

class Work(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    subject = models.CharField(max_length=40)
    desc = models.TextField()
    date = models.DateField()
    status = models.BooleanField(default=False)

class MyProfile(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    my_profile = models.ImageField(upload_to='profile')

class Document(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    name = models.CharField(max_length=50)
    docs = models.FileField(upload_to='My_docs')

class Question(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    Que = models.TextField()