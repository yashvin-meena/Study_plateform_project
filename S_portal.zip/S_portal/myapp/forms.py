from django import forms
from . import models
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm,UserChangeForm,AuthenticationForm,UsernameField,PasswordChangeForm
class NotesForm(forms.ModelForm):
    class Meta:
        model = models.Notes
        fields = ['title','desc']
        labels = {'title':'Title','desc':'Description'}
        widgets = {'title':forms.TextInput(attrs={'class':'form-control','placeholder':'Title'}),
                   'desc':forms.Textarea(attrs={'class':'form-control','placeholder':'write...'})}
        
class WorkForm(forms.ModelForm):
    class Meta:
        model = models.Work
        fields = '__all__'
        exclude = ['user','id']
        widgets = {'subject':forms.TextInput(attrs={'class':'form-control','placeholder':'subject'}),
                   'desc':forms.Textarea(attrs={'class':'form-control','placeholder':'Description...'}),
                   'date':forms.DateInput(attrs={'class':'form-control','type':'date'}),
                   'status':forms.CheckboxInput(attrs={'class':'form-check-input me-3'}),
                }
        labels = {'status':'Have you finished it..?',
                  'subject':'',
                  'date':'',
                  'desc':''}
    
class RegistrationForm(UserCreationForm):
    password1 = forms.CharField(label='password',widget=forms.PasswordInput(attrs={'class':'form-control'}))
    password2 = forms.CharField(label='password(again)',widget=forms.PasswordInput(attrs={'class':'form-control'}))
    class Meta:
        model = User
        fields = ['username','first_name','last_name','email']
        widgets = {
            'username':forms.TextInput(attrs={'class':'form-control'}),
            'first_name':forms.TextInput(attrs={'class':'form-control'}),
            'last_name':forms.TextInput(attrs={'class':'form-control'}),
            'email':forms.EmailInput(attrs={'class':'form-control'}),
            'password':forms.PasswordInput(attrs={'class':'form-control'}),
        }

class ProfileForm(UserChangeForm):
    password = None
    class Meta:
        model = User
        fields = ['username','first_name','last_name','email']
        widgets = {
            'username':forms.TextInput(attrs={'class':'form-control'}),
            'first_name':forms.TextInput(attrs={'class':'form-control'}),
            'last_name':forms.TextInput(attrs={'class':'form-control'}),
            'email':forms.EmailInput(attrs={'class':'form-control'})}

class ProfilePicture(forms.ModelForm):
    class Meta:
        model = models.MyProfile
        fields = ['my_profile']
        widgets = {'my_profile':forms.FileInput(attrs={'class':'form-control'})}
    
class UserAuthentication(AuthenticationForm):
        username = UsernameField(widget=forms.TextInput(attrs={'class':'form-control'}))
        password = forms.CharField(strip=False,widget=forms.PasswordInput(attrs={'class':'form-control','autocomplete':'current-password'}),)
    
class ApiForm(forms.Form):
    word = forms.CharField(max_length=100,label='',widget=forms.TextInput(attrs={'class':'form-control fw-bold','placeholder':'Enter Your Word...'}))

class DocumentForm(forms.ModelForm):
    class Meta:
        model = models.Document
        fields = ['name','docs']
        widgets = {'name':forms.TextInput(attrs={'class':'form-control'}),
                   'docs':forms.FileInput(attrs={'class':'form-control'})}

operator_choice = (
    ('+','+'),
    ('-','-'),
    ('*','*'),
    ('/','/')
)

class Calculation(forms.Form):
    value_1 = forms.IntegerField(widget=forms.NumberInput(attrs={'class':'form-control'}))
    value_2 = forms.IntegerField(widget=forms.NumberInput(attrs={'class':'form-control'}))
    # operator = forms.ChoiceField(choices=operator_choice,widget=forms.RadioSelect(attrs={'class':'form-check-input'}))

class Faq_Form(forms.ModelForm):
    class Meta:
        model = models.Question
        fields = ['Que']
        widgets = {'Que':forms.Textarea(attrs={'class':'form-control'})}
    
class PasswordsetForm(PasswordChangeForm):
    old_password = forms.CharField(widget=forms.PasswordInput(attrs={'class':'form-control'}),)
    new_password1 = forms.CharField(label='New-password',widget=forms.PasswordInput(attrs={'class':'form-control'}),)
    new_password2 = forms.CharField(label='Confirm',widget=forms.PasswordInput(attrs={'class':'form-control'}),)
    class Meta:
        model = User
        fields = '__all__'

    