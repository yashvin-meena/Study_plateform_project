from django.contrib import admin
from . import models
# Register your models here.
@admin.register(models.Card)
class Cards(admin.ModelAdmin):
    list_display = ['id','heading','img','description']

@admin.register(models.Notes)
class StudentNotes(admin.ModelAdmin):
    list_display = ['id','title','user']

@admin.register(models.Work)
class StudentWork(admin.ModelAdmin):
    list_display = ['id','subject','desc','date','status']

@admin.register(models.MyProfile)
class ProfileDisplay(admin.ModelAdmin):
    list_display = ['id','my_profile']

@admin.register(models.Document)
class DocumentHolder(admin.ModelAdmin):
    list_display = ['id','name','docs']

@admin.register(models.Question)
class Frequently(admin.ModelAdmin):
    list_display = ['id','Que']