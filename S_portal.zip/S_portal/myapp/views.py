from django.shortcuts import render,redirect
from .forms import NotesForm,WorkForm,RegistrationForm,ProfileForm,ProfilePicture,UserAuthentication,ApiForm,DocumentForm,Calculation,Faq_Form,PasswordsetForm
from .models import Notes,Work,User,MyProfile,Card,Document,Question
from django.contrib.auth import login,logout,authenticate
from django.contrib.auth.views import LoginView
from django.contrib import messages
from django.views import View
import requests
from django.contrib.auth.decorators import login_required
from django.urls.resolvers import get_resolver
from youtubesearchpython import VideosSearch

# # Create your views here.
# def random_url_view(request,random_url):
#     resolver = get_resolver()
#     view_func = resolver.resolve(random_url).func
#     response = view_func(request,random_url)
#     return response

def Registration(request):
    # def get(self,request):
    if request.method == 'GET':
        form = RegistrationForm()
        print('get______________')
    
    elif request.method =='POST':
        print('post_____________')
        form = RegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,'Registered successfully !!')
            form = RegistrationForm()
    return render(request,'myapp/reg.html',{'form':form})

# class MyLogin(LoginView):
#     template_name = 'myapp/login.html'
#     form_class = UserAuthentication
    

def user_login(request):
    if not request.user.is_authenticated: 
        if request.method == 'POST':
            form = UserAuthentication(request=request, data=request.POST)
            if form.is_valid():
                uname = form.cleaned_data['username']
                upass = form.cleaned_data['password']
                user = authenticate(username=uname,password=upass)
                if user is not None:
                    login(request,user)
                    print(user)
                # if user.is_superuser: 
                    # user is logged in here so this one redirect to super user
                    # return redirect('/')
                # if not super user then redirect to as a normal user
                return redirect('/')
        else:
            form = UserAuthentication()
        return render(request,'myapp/login.html',{'form':form})
    else:
        return redirect('/')

@login_required
def user_logout(request):
    logout(request)
    return redirect('/login/')

def set_password(request):
    if request.method == 'POST':
        form = PasswordsetForm(user=request.user,data=request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,'Password updated !!')
        return redirect('/')
    form = PasswordsetForm(user=request.user)
    return render(request,'myapp/set_pass.html',{"form":form})

def home(request):
    if request.user.is_superuser:
            comment = Question.objects.all()
            return render(request,'myapp/admin_panel.html',{'cmt':comment})
    cards = Card.objects.all()
    return render(request,'myapp/home.html',{'cards':cards})

class Search(View):
    def get(self,request):
        value = request.GET.get('search')
        if not value:
            return redirect('/')
        searched = Card.objects.filter(heading__icontains=value)
        # if item exist then if or else else part which is validator
        if searched:
            searched = searched
        else:
            searched = None
        return render(request,'myapp/home.html',{'cards':searched})

@login_required
def notes(request):
    if request.method == 'POST':
        form = NotesForm(request.POST)
        if form.is_valid():
            title = form.cleaned_data['title']
            desc = form.cleaned_data['desc']
            user = request.user
            note = Notes(title=title,desc=desc,user=user)
            note.save()
            messages.success(request,'Notes created successfully !!')
    else:
        form = NotesForm()
    notes = Notes.objects.filter(user=request.user)
    return render(request,'myapp/notes.html',{'form':form,'notes':notes})

@login_required
def note_detail(request,id):
    note = Notes.objects.get(pk=id)
    return render(request,'myapp/n_detail.html',{'note':note})

@login_required
def delete_note(request,id):
    note = Notes.objects.get(pk=id)
    note.delete()
    messages.error(request,'Notes deleted !!')
    return redirect('/notes/')

class WorkView(View):
    def get(self,request):
     if request.user.is_authenticated:
        form = WorkForm()
        works = Work.objects.filter(user=request.user)
        return render(request,'myapp/work.html',{'form':form,'works':works})
     elif request.user.is_anonymous:
         return redirect('/login')
    def post(self,request):
        form = WorkForm(request.POST)
        if form.is_valid():
            sub = form.cleaned_data['subject']
            description = form.cleaned_data['desc']
            add_date = form.cleaned_data['date']
            status = form.cleaned_data['status']
            homework = Work(subject=sub,desc=description,date=add_date,status=status,user=request.user)
            homework.save()
            messages.success(request,'Added Successfully !!')
            works = Work.objects.filter(user=request.user)
            return render(request,'myapp/work.html',{'form':form,'works':works})

@login_required
def work_update(requset,id):
    work = Work.objects.get(pk=id)
    if work.status == True:
        work.status = False
    
    else:
        work.status = True
    work.save()
    return redirect('/work/')

@login_required
def work_delete(request,id):
    work = Work.objects.get(pk=id)
    work.delete()
    messages.error(request,'Work Deleted !!')
    return redirect('/work/')

@login_required
def dashboard(request):
    works = Work.objects.filter(user=request.user,status=False)
    work = len(works)
    return render(request,'myapp/dashboard.html',{'works':works,'work':work})

@login_required
def profile(request):
    if request.method == 'POST':
        form = ProfileForm(request.POST,instance=request.user)
        if form.is_valid():
            form.save()
            data = User.objects.get(pk=request.user.id)
            messages.success(request,'Profile Updated !!')
    else: 
        form = ProfileForm(instance=request.user)
        data = User.objects.get(pk=request.user.id)
    # code for getting latest picture
    user_all_img = MyProfile.objects.filter(user=request.user)
    value = user_all_img.values()
    max = 0
    for i in range(len(value)):
        if value[i]['id'] > max:
            max = value[i]['id']
    if max:
        p_img = MyProfile.objects.get(pk=max)
    else:
        p_img = None
    return render(request,'myapp/profile.html',{'form':form,'data':data,'p_img':p_img})

@login_required
def profile_pic(request):
    if request.method == 'POST':
        form = ProfilePicture(request.POST,request.FILES)
        print(form)
        if form.is_valid():
            img = form.cleaned_data['my_profile']
            user = request.user
            pimg = MyProfile(my_profile=img,user=user)
            pimg.save()
            messages.success(request,'profile picture uploaded !!')
        return redirect('/profile/') 
    form = ProfilePicture()
    picture_form = {
        'form':form
    }
    return render(request,'myapp/profile_pic.html',picture_form)

def dictionary(request):
    if request.method == 'POST':
        form = ApiForm(request.POST)
        text = request.POST.get('word')
        url = "https://api.dictionaryapi.dev/api/v2/entries/en_US/"+text
        r = requests.get(url)
        answer = r.json()
        try:
            phonetics = answer[0]['phonetics'][0]['text']
            audio = answer[0]['phonetics'][0]['audio']
            definition = answer[0]['meanings'][0]['definitions'][0]['definition']
            example = answer[0]['meanings'][0]['definitions'][0]['example']
            synonyms = answer[0]['meanings'][0]['definitions'][0]['synonyms']
            context = {
                'forms':form,
                'input': text,
                'phonetics': phonetics,
                'audio': audio,
                'definition': definition,
                'example': example,
                's': synonyms
            }


        except:
            context = {
                'forms':form,
                'input': ''
            }
        return render(request,'myapp/dict.html',context)
    else:
        form = ApiForm()
        context = {
            'forms':form
        }
    return render(request,'myapp/dict.html',context)


def book_section(request):
    if request.method == 'POST':
        form = ApiForm(request.POST)
        text = request.POST.get('word')
        print(type(text))
        url = "https://www.googleapis.com/books/v1/volumes?q="+text
        r = requests.get(url)
        answer = r.json()
        result_list = []
        for i in range(10):
            result_dict = {
                'input':text,
                'title':answer['items'][i]['volumeInfo']['title'],
                'subtitle':answer['items'][i]['volumeInfo'].get('subtitle'),
                'description':answer['items'][i]['volumeInfo'].get('description'),
                'count':answer['items'][i]['volumeInfo'].get('pageCount'),
                'categories':answer['items'][i]['volumeInfo'].get('categories'),
                'rating':answer['items'][i]['volumeInfo'].get('pageRating'),
                'thumbnail':answer['items'][i]['volumeInfo'].get('imageLinks').get('thumbnail'),
                'preview':answer['items'][i]['volumeInfo'].get('previewLink'),
                
            }
            result_list.append(result_dict)
            context = {
             'form': form,
             'results':result_list
            }
        return render(request,'myapp/book.html',context)
    else:
        form = ApiForm()
        context = {
            'form': form
        }
    return render(request,'myapp/book.html',context)


def youtube(request):
    if request.method == 'POST':
        form = ApiForm(request.POST)
        text = request.POST.get('word')
        video = VideosSearch(text,limit=10)
        result_list = []
        for i in video.result()['result']:
            result_dict = {
                'input':text,
                'title':i['title'],
                'duration':i['duration'],
                'thumbnail':i['thumbnails'][0]['url'],
                'channel':i['channel']['name'],
                'link':i['link'],
                'views':i['viewCount']['short'],
                'published':i['publishedTime']
            }

            desc=''
            if i['descriptionSnippet']:
                for j in i['descriptionSnippet']:
                  desc += j['text']
            result_dict['description'] = desc
            result_list.append(result_dict)
            context = {
             'form': form,
             'results':result_list
            }
        return render(request,'myapp/youtube.html',context)
    else:
        form = ApiForm()
    context = {
        'form': form
    }
    return render(request,'myapp/youtube.html',context)


@login_required
def docs_uploader(request):
    if request.method == 'POST':
        docs_form = DocumentForm(request.POST,request.FILES)
        if docs_form.is_valid():
            name = docs_form.cleaned_data['name']
            docs = docs_form.cleaned_data['docs']
            user = request.user
            my_docs = Document(name=name,docs=docs,user=user)
            my_docs.save()
            docs_list = Document.objects.filter(user=request.user)
            messages.success(request,'Docs uploaded !!')
    else:
        docs_form = DocumentForm()
        docs_list = Document.objects.filter(user=request.user)
        if docs_list:
            docs_list = docs_list
        else:
            docs_list = None

    context = {'dform':docs_form,
               'd_list':docs_list}
    return render(request,'myapp/d_uploader.html',context)

def math_operation(request):
    if request.method == 'POST':
        print('--------------------')
        form = Calculation(request.POST)
        if form.is_valid():
            v1 = int(form.cleaned_data['value_1'])
            v2 = int(form.cleaned_data['value_2'])
            opr = request.POST.get('operator')
            if opr =='+':
                final = v1+v2
            elif opr =='-':
                final = v1-v2
            elif opr == '*':
                final = v1*v2
            else:
                final = v1/v2
    else:
        form = Calculation()
        final=None
    return render(request,'myapp/math.html',{'form':form,'final':final})

def forgot_password(request):
    if request.method  == 'POST':
        # name = request.POST.get('name','empty')
        # email = request.POST.get('email','empty')
        # new_pass = request.POST.get('password','empty')
        # user = User.objects.get(username=name,email=email) 
        # print(name,email,new_pass)
        # print('old passsword:',user.password)
        # if user is not None:
        #     print('user record:',user)
        #     new_data = User(id=user.id,username=user.username,first_name=user.first_name,last_name=user.last_name,email=user.email,password=new_pass)
        #     new_data.save()
        #     messages.success(request,'password changed !!')
        return redirect('/login/')
    return render(request,'myapp/forgot.html')

def faqview(request):
    if request.method == 'POST':
        form = Faq_Form(request.POST)
        if form.is_valid():
            user = request.user
            question = form.cleaned_data['Que']
            user_Q = Question(Que=question,user=user)
            user_Q.save()
            messages.success(request,'Succesfully Sent !!')
    else:
        form = Faq_Form()
    return render(request,'myapp/faq.html',{'form':form})

def User_list(request):
    if request.method == 'POST':
        u_name = request.POST.get('uname')
        users = User.objects.filter(username__startswith = u_name)
    else:
        users = User.objects.all()
    return render(request,'myapp/users.html',{'users':users})

def user_messages(request):
    messages = Question.objects.all()
    return render(request,'myapp/messages.html',{'messages':messages})

def message_delete(request,m_id):
    message = Question.objects.get(pk=m_id)
    message.delete()
    return redirect('/messages/')
