from django.urls import path
from . import views
urlpatterns = [
    path('',views.home,name='home'),
    path('registration/',views.Registration,name='registration'),
    path('login/',views.user_login,name='login'),
    path('logout/',views.user_logout,name='logout'),
    path('new-pass/',views.set_password,name='set-pass'),
    path('notes/',views.notes,name='notes'),
    path('delete_notes/<int:id>/',views.delete_note,name='delete_note'),
    path('detail/<int:id>',views.note_detail,name='n_detail'),
    path('work/',views.WorkView.as_view(),name='work'),
    path('update_work/<int:id>',views.work_update,name='update_work'),
    path('delete_work/<int:id>',views.work_delete,name='delete_work'),
    path('dashboard/',views.dashboard,name='dashboard'),
    path('profile/',views.profile,name='profile'),
    path('profile-image/',views.profile_pic,name='p_pic'),
    path('/',views.Search.as_view(),name='search'),
    path('dict/',views.dictionary,name='dict'),
    path('book/',views.book_section,name='book'),
    path('youtube/',views.youtube,name='youtube'),
    path('docs/',views.docs_uploader,name='docs'),
    path('math/',views.math_operation,name='math'),
    path('faq/',views.faqview,name='faq'),
    path('users/',views.User_list,name='users'),
    path('messages/',views.user_messages,name='messages'),
    path('m_delete/<int:m_id>',views.message_delete,name='msg_del'),
    path('forgot-pass/',views.forgot_password,name='forgot')
]